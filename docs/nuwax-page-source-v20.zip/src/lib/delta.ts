/**
 * 三角洲配装作战台 — 工作流接入、配置与本地历史。
 *
 * 工作流：df_搭配_绝密预算V19_1（资源 ID 5268226）
 * 端点：POST /api/page/w/17923804395268226
 * 唯一入参：request_json（JSON 字符串）
 */

export const WORKFLOW_ID = '5268226';
export const WORKFLOW_NAME = 'df_搭配_绝密预算V19_1';
export const WORKFLOW_ENDPOINT = '/api/page/w/17923804395268226';

/** 工作流报告域名（严格限定，仅允许该 origin）。 */
export const REPORT_ORIGIN =
  'https://delta-loadout-visual-report.snowy-grebe-0462.chatgpt.site';

/** 单次核价的最长等待时间。工作流为同步返回，需要给足生成报告的时间。 */
const WORKFLOW_TIMEOUT_MS = 600_000;

export interface MapConfig {
  name: string;
  difficulties: readonly string[];
}

/** 地图与合法难度映射。切换地图后若当前难度不合法，自动选择第一个。 */
export const MAP_CONFIGS: readonly MapConfig[] = [
  { name: '零号大坝', difficulties: ['常规', '机密', '永夜'] },
  { name: '长弓溪谷', difficulties: ['常规', '机密'] },
  { name: '巴克什', difficulties: ['机密', '绝密'] },
  { name: '航天基地', difficulties: ['机密', '绝密'] },
  { name: '潮汐监狱', difficulties: ['绝密'] },
  { name: 'AZ3', difficulties: ['常规', '机密'] },
];

export const DEFAULT_MAP = '长弓溪谷';
export const DEFAULT_DIFFICULTY = '常规';
export const DEFAULT_BUDGET_WAN = '50';
export const BUDGET_PRESETS = [30, 50, 100, 150, 200] as const;

/** 各难度的预算上限（万哈夫币）。超出仅提示，工作流负责封顶。 */
export const DIFFICULTY_BUDGET_CAP_WAN: Readonly<Record<string, number>> = {
  常规: 150,
  机密: 300,
  绝密: 600,
  永夜: 600,
};

export function getDifficulties(mapName: string): readonly string[] {
  return MAP_CONFIGS.find(item => item.name === mapName)?.difficulties ?? [];
}

/** 返回当前地图下可用的难度；当前难度合法则保留，否则取第一个。 */
export function resolveDifficulty(mapName: string, current: string): string {
  const difficulties = getDifficulties(mapName);
  if (difficulties.includes(current)) return current;
  return difficulties[0] ?? '';
}

export function getBudgetCapWan(difficulty: string): number | null {
  return DIFFICULTY_BUDGET_CAP_WAN[difficulty] ?? null;
}

export interface BudgetCheck {
  value?: number;
  error?: string;
}

/** 预算必须为正数，最多两位小数。 */
export function validateBudgetInput(raw: string): BudgetCheck {
  const trimmed = raw.trim();
  if (!trimmed) return { error: '请输入整套预算（万哈夫币）。' };
  if (!/^\d+(\.\d{1,2})?$/.test(trimmed)) {
    return { error: '预算必须是正数，最多两位小数。' };
  }
  const value = Number(trimmed);
  if (!Number.isFinite(value) || value <= 0) {
    return { error: '预算必须大于 0。' };
  }
  return { value };
}

export interface LoadoutRequest {
  map: string;
  difficulty: string;
  budgetWan: number;
  allowRare: boolean;
  allowDamaged: boolean;
}

export interface RunSnapshot extends LoadoutRequest {
  submittedAt: string;
}

export interface WorkflowResult {
  output: string;
  reportUrl: string;
  reportHash: string;
  missingInput: string;
  mapError: string;
}

export interface LoadoutResult {
  snapshot: RunSnapshot;
  output: string;
  reportUrl: string;
  reportHash: string;
  finishedAt: string;
  source: 'workflow' | 'history';
}

export interface RunError {
  message: string;
  detail?: string;
  snapshot: RunSnapshot;
}

export type WorkflowErrorKind = 'network' | 'server' | 'business' | 'invalid';

export class WorkflowError extends Error {
  readonly kind: WorkflowErrorKind;
  readonly detail?: string;

  constructor(message: string, kind: WorkflowErrorKind, detail?: string) {
    super(message);
    this.name = 'WorkflowError';
    this.kind = kind;
    this.detail = detail;
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null;
}

function asString(value: unknown): string {
  return typeof value === 'string' ? value : '';
}

/** 提取报告 URL 中 `#r=` 之后的原始字符（不 decode、不重编码）。 */
export function extractReportHash(url: string): string {
  const marker = '#r=';
  const index = url.indexOf(marker);
  return index >= 0 ? url.slice(index + marker.length) : '';
}

/** 报告链接域名严格校验。 */
export function isAllowedReportUrl(raw: string): boolean {
  if (!raw) return false;
  try {
    const url = new URL(raw);
    return url.protocol === 'https:' && url.origin === REPORT_ORIGIN;
  } catch {
    return false;
  }
}

function parseWorkflowResponse(payload: unknown): WorkflowResult {
  if (!isRecord(payload)) {
    throw new WorkflowError('服务返回数据为空，请稍后重试。', 'invalid');
  }

  const message = asString(payload.message);
  if (payload.success !== true) {
    throw new WorkflowError(
      message || '工作流执行失败，请稍后重试。',
      'server'
    );
  }

  if (!isRecord(payload.data)) {
    throw new WorkflowError('工作流未返回结果数据，请重试。', 'invalid');
  }

  const output = asString(payload.data.output);
  const reportUrl = asString(payload.data.report_url);
  const missingInput = asString(payload.data.missing_input);
  const mapError = asString(payload.data.map_error);

  if (missingInput) {
    throw new WorkflowError(`参数缺失：${missingInput}`, 'business', output);
  }
  if (mapError) {
    throw new WorkflowError(`地图参数错误：${mapError}`, 'business', output);
  }
  if (!output && !reportUrl) {
    throw new WorkflowError('工作流未返回配装结果，请重试。', 'business');
  }

  return {
    output,
    reportUrl,
    reportHash: extractReportHash(reportUrl),
    missingInput,
    mapError,
  };
}

/**
 * 调用真实工作流。唯一入参为 request_json 字符串。
 * 同步等待完整响应，不把任何中间态当作完成。
 */
export async function runLoadoutWorkflow(
  request: LoadoutRequest
): Promise<WorkflowResult> {
  const requestJson = JSON.stringify({
    map: request.map,
    difficulty: request.difficulty,
    budget: Math.round(request.budgetWan * 10000),
    allow_rare: request.allowRare,
    allow_damaged: request.allowDamaged,
  });

  const controller = new AbortController();
  const timer = window.setTimeout(
    () => controller.abort(),
    WORKFLOW_TIMEOUT_MS
  );

  try {
    const response = await fetch(WORKFLOW_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      // 严格只传 request_json，不拆分字段。
      body: JSON.stringify({ request_json: requestJson }),
      credentials: 'same-origin',
      signal: controller.signal,
    });

    const rawText = await response.text();
    let payload: unknown = null;
    if (rawText) {
      try {
        payload = JSON.parse(rawText);
      } catch {
        throw new WorkflowError(
          '服务返回了无法解析的数据，请稍后重试。',
          'invalid'
        );
      }
    }

    if (!response.ok) {
      const message = isRecord(payload) ? asString(payload.message) : '';
      throw new WorkflowError(
        message || `服务响应异常（HTTP ${response.status}），请稍后重试。`,
        'server'
      );
    }

    return parseWorkflowResponse(payload);
  } catch (error) {
    if (error instanceof WorkflowError) throw error;
    if (error instanceof DOMException && error.name === 'AbortError') {
      throw new WorkflowError('核价超时，请稍后重试。', 'network');
    }
    throw new WorkflowError('网络连接失败，请检查网络后重试。', 'network');
  } finally {
    window.clearTimeout(timer);
  }
}

/* ------------------------------------------------------------------ */
/* 本地历史（仅本机，最多 5 份，读写异常不得影响报告展示）              */
/* ------------------------------------------------------------------ */

const HISTORY_KEY = 'delta-loadout.reports.v1';
export const HISTORY_LIMIT = 5;

export interface HistoryEntry {
  id: string;
  savedAt: string;
  request: LoadoutRequest;
  reportUrl: string;
  reportHash: string;
  summary: string;
}

function isHistoryEntry(value: unknown): value is HistoryEntry {
  if (!isRecord(value)) return false;
  const request = value.request;
  return (
    typeof value.id === 'string' &&
    typeof value.savedAt === 'string' &&
    typeof value.reportUrl === 'string' &&
    typeof value.reportHash === 'string' &&
    typeof value.summary === 'string' &&
    isRecord(request) &&
    typeof request.map === 'string' &&
    typeof request.difficulty === 'string' &&
    typeof request.budgetWan === 'number' &&
    typeof request.allowRare === 'boolean' &&
    typeof request.allowDamaged === 'boolean'
  );
}

export function loadHistory(): HistoryEntry[] {
  try {
    const raw = window.localStorage.getItem(HISTORY_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(isHistoryEntry).slice(0, HISTORY_LIMIT);
  } catch {
    return [];
  }
}

function createHistoryId(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
    return crypto.randomUUID();
  }
  return `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

/** 将成功结果转成历史记录。summary 为去格式后的短摘要。 */
export function createHistoryEntry(result: LoadoutResult): HistoryEntry {
  return {
    id: createHistoryId(),
    savedAt: result.finishedAt,
    request: {
      map: result.snapshot.map,
      difficulty: result.snapshot.difficulty,
      budgetWan: result.snapshot.budgetWan,
      allowRare: result.snapshot.allowRare,
      allowDamaged: result.snapshot.allowDamaged,
    },
    // 完整 URL 原样保存，不做任何重编码或截断。
    reportUrl: result.reportUrl,
    reportHash: result.reportHash,
    summary: summarizeOutput(result.output),
  };
}

/**
 * 写入历史。即使 localStorage 抛异常，也返回内存中的最新列表，
 * 保证报告展示与本次成功结果不受影响。
 */
export function pushHistory(
  entry: HistoryEntry,
  current: HistoryEntry[]
): HistoryEntry[] {
  const next = [
    entry,
    ...current.filter(item =>
      entry.reportUrl
        ? item.reportUrl !== entry.reportUrl
        : item.id !== entry.id
    ),
  ].slice(0, HISTORY_LIMIT);

  try {
    window.localStorage.setItem(HISTORY_KEY, JSON.stringify(next));
  } catch {
    // 忽略存储异常（无痕模式、配额已满等）。
  }

  return next;
}

/** 把历史记录还原成当前结果视图。 */
export function historyToResult(entry: HistoryEntry): LoadoutResult {
  return {
    snapshot: { ...entry.request, submittedAt: entry.savedAt },
    output: entry.summary,
    reportUrl: entry.reportUrl,
    reportHash: entry.reportHash,
    finishedAt: entry.savedAt,
    source: 'history',
  };
}

/* ------------------------------------------------------------------ */
/* 展示辅助                                                            */
/* ------------------------------------------------------------------ */

/** 万元值展示：整数不带小数，小数最多保留两位并去掉末尾 0。 */
export function formatWan(value: number): string {
  if (!Number.isFinite(value)) return '—';
  const fixed = value.toFixed(2).replace(/0+$/, '').replace(/\.$/, '');
  return fixed;
}

/**
 * 生成纯文本费用摘要（历史卡片使用）。
 * 删除 Markdown 链接、裸 URL、data URI 与超长 base64 串，避免泄露报告原文。
 */
export function summarizeOutput(output: string, maxLength = 220): string {
  const plain = output
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/?[a-zA-Z][^>]*>/g, ' ')
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/!\[[^\]]*\]\((?:https?:\/\/|data:)[^\s)]*\)/gi, ' ')
    .replace(/\[[^\]]*\]\((?:https?:\/\/|data:)[^\s)]*\)/gi, ' ')
    .replace(/\b(?:https?:\/\/|data:)[^\s<>"'()[\]{}，。；、！？]+/gi, ' ')
    .replace(/#r=[A-Za-z0-9+/=%._-]{20,}/g, ' ')
    .replace(/[A-Za-z0-9+/=_-]{80,}/g, ' ')
    .replace(/^[\s#>*+-]+/gm, '')
    .replace(/[*_`~]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  if (!plain) return '未返回文字摘要。';
  if (plain.length <= maxLength) return plain;
  return `${plain.slice(0, maxLength)}…`;
}

export function formatTimestamp(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  return new Intl.DateTimeFormat('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  }).format(date);
}
