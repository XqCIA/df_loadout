import { useCallback, useMemo, useRef, useState } from 'react';
import type { FormEvent, ReactNode } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  ChevronDown,
  Crosshair,
  FileText,
  History,
  Loader2,
  RotateCcw,
  SlidersHorizontal,
  Target,
} from 'lucide-react';
import { SafeMarkdown } from '@/components/delta/SafeMarkdown';
import { ReportViewer } from '@/components/delta/ReportViewer';
import { HistoryList } from '@/components/delta/HistoryList';
import {
  BUDGET_PRESETS,
  DEFAULT_BUDGET_WAN,
  DEFAULT_DIFFICULTY,
  DEFAULT_MAP,
  MAP_CONFIGS,
  createHistoryEntry,
  formatTimestamp,
  formatWan,
  getBudgetCapWan,
  getDifficulties,
  historyToResult,
  loadHistory,
  pushHistory,
  resolveDifficulty,
  runLoadoutWorkflow,
  validateBudgetInput,
  WorkflowError,
  type HistoryEntry,
  type LoadoutRequest,
  type LoadoutResult,
  type RunError,
  type RunSnapshot,
} from '@/lib/delta';
import { cn } from '@/lib/utils';

function SectionHeading({
  index,
  title,
  right,
}: {
  index: string;
  title: string;
  right?: ReactNode;
}) {
  return (
    <div className='mb-3 flex flex-wrap items-center gap-2.5'>
      <span className='df-index'>{index}</span>
      <h2 className='text-sm font-bold tracking-wide text-[#ecf8ee]'>
        {title}
      </h2>
      {right ? <div className='ml-auto'>{right}</div> : null}
    </div>
  );
}

function ToggleRow({
  checked,
  onChange,
  title,
  description,
}: {
  checked: boolean;
  onChange: (next: boolean) => void;
  title: string;
  description: string;
}) {
  return (
    <div className='flex items-start justify-between gap-4 rounded-xl border border-[#1d3a2b] bg-[#06180f]/70 p-3.5'>
      <div className='min-w-0'>
        <p className='text-sm font-semibold text-[#e6f2e9]'>{title}</p>
        <p className='mt-0.5 text-[11px] leading-relaxed text-[#7f9c8b]'>
          {description}
        </p>
      </div>
      <button
        type='button'
        role='switch'
        aria-checked={checked}
        aria-label={title}
        onClick={() => onChange(!checked)}
        className={cn(
          'relative mt-0.5 h-6 w-11 shrink-0 rounded-full border transition-colors',
          checked
            ? 'border-[#c8f751] bg-[#c8f751]'
            : 'border-[#2a4436] bg-[#12291d]'
        )}
      >
        <span
          className={cn(
            'absolute top-[3px] h-[18px] w-[18px] rounded-full transition-all',
            checked
              ? 'left-[3px] translate-x-5 bg-[#07130c]'
              : 'left-[3px] bg-[#7f9c8b]'
          )}
        />
      </button>
    </div>
  );
}

function Home() {
  const [map, setMap] = useState(DEFAULT_MAP);
  const [difficulty, setDifficulty] = useState(DEFAULT_DIFFICULTY);
  const [budgetRaw, setBudgetRaw] = useState(DEFAULT_BUDGET_WAN);
  const [budgetTouched, setBudgetTouched] = useState(false);
  const [allowRare, setAllowRare] = useState(false);
  const [allowDamaged, setAllowDamaged] = useState(true);
  const [advancedOpen, setAdvancedOpen] = useState(false);

  const [running, setRunning] = useState(false);
  const [runningSnapshot, setRunningSnapshot] = useState<RunSnapshot | null>(
    null
  );
  const [result, setResult] = useState<LoadoutResult | null>(null);
  const [error, setError] = useState<RunError | null>(null);
  const [history, setHistory] = useState<HistoryEntry[]>(() => loadHistory());
  const [activeHistoryId, setActiveHistoryId] = useState<string | null>(null);

  const resultAnchorRef = useRef<HTMLElement | null>(null);
  const lastAttemptRef = useRef<LoadoutRequest | null>(null);

  const difficulties = useMemo(() => getDifficulties(map), [map]);
  const budgetCheck = useMemo(
    () => validateBudgetInput(budgetRaw),
    [budgetRaw]
  );
  const budgetCap = getBudgetCapWan(difficulty);
  const overCap =
    budgetCheck.value !== undefined &&
    budgetCap !== null &&
    budgetCheck.value > budgetCap;
  const showBudgetError =
    Boolean(budgetCheck.error) &&
    (budgetTouched || budgetRaw.trim().length > 0);

  const execute = useCallback(async (request: LoadoutRequest) => {
    const snapshot: RunSnapshot = {
      ...request,
      submittedAt: new Date().toISOString(),
    };

    lastAttemptRef.current = request;
    setRunningSnapshot(snapshot);
    setRunning(true);
    setError(null);
    setActiveHistoryId(null);
    resultAnchorRef.current?.scrollIntoView({
      behavior: 'smooth',
      block: 'start',
    });

    try {
      const data = await runLoadoutWorkflow(request);
      const finishedAt = new Date().toISOString();
      const nextResult: LoadoutResult = {
        snapshot,
        output: data.output,
        reportUrl: data.reportUrl,
        reportHash: data.reportHash,
        finishedAt,
        source: 'workflow',
      };

      // 失败不会走到这里，因此上一次成功结果不会被覆盖。
      setResult(nextResult);
      setHistory(current =>
        pushHistory(createHistoryEntry(nextResult), current)
      );
    } catch (err) {
      const message =
        err instanceof WorkflowError ? err.message : '核价失败，请稍后重试。';
      const detail = err instanceof WorkflowError ? err.detail : undefined;
      setError({ message, detail, snapshot });
    } finally {
      setRunning(false);
      setRunningSnapshot(null);
    }
  }, []);

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (running) return;

    setBudgetTouched(true);
    const check = validateBudgetInput(budgetRaw);
    if (check.value === undefined) return;

    void execute({
      map,
      difficulty,
      budgetWan: check.value,
      allowRare,
      allowDamaged,
    });
  };

  const handleMapChange = (nextMap: string) => {
    setMap(nextMap);
    setDifficulty(current => resolveDifficulty(nextMap, current));
  };

  const handleRetry = () => {
    if (lastAttemptRef.current) void execute(lastAttemptRef.current);
  };

  const handleSelectHistory = (entry: HistoryEntry) => {
    setResult(historyToResult(entry));
    setActiveHistoryId(entry.id);
    setError(null);
    resultAnchorRef.current?.scrollIntoView({
      behavior: 'smooth',
      block: 'start',
    });
  };

  const statusLabel = running
    ? '核价中'
    : error
      ? '请求异常'
      : result
        ? '报告就绪'
        : '待命';

  return (
    <div className='relative min-h-screen overflow-x-hidden'>
      <div aria-hidden='true' className='df-backdrop' />

      <div className='mx-auto w-full max-w-6xl px-4 pb-14 sm:px-6'>
        {/* 顶部状态条 */}
        <div className='flex items-center justify-between gap-3 border-b border-[#1d3a2b]/80 py-3 font-mono text-[10px] uppercase tracking-[0.2em] text-[#6f8c7b]'>
          <span className='flex items-center gap-2'>
            <span className='h-1.5 w-1.5 animate-pulse rounded-full bg-[#c8f751]' />
            DF LOADOUT OPS
          </span>
          <span className='truncate'>TACTICAL CONSOLE · V20</span>
        </div>

        {/* 标题 */}
        <header className='pb-7 pt-8 sm:pb-9 sm:pt-11'>
          <p className='font-mono text-[11px] tracking-[0.3em] text-[#c8f751]'>
            DELTA FORCE // LOADOUT
          </p>
          <h1 className='mt-3 text-3xl font-black leading-tight tracking-tight text-[#f1fbef] sm:text-4xl lg:text-5xl'>
            三角洲配装作战台
          </h1>
          <p className='mt-3 text-sm text-[#9ab5a5] sm:text-base'>
            选地图 · 定预算 · 一键看配装
          </p>

          <div className='mt-5 flex flex-wrap gap-2'>
            {['枪械配件', '装备', '弹药', '补给'].map(item => (
              <span
                key={item}
                className='inline-flex items-center gap-1.5 rounded-full border border-[#1d3a2b] bg-[#071b13]/80 px-3 py-1 text-[11px] text-[#9ab5a5]'
              >
                <span className='h-1 w-1 rounded-full bg-[#c8f751]' />
                {item}
              </span>
            ))}
          </div>
        </header>

        {/* 主表单 */}
        <form
          onSubmit={handleSubmit}
          noValidate
          className='df-card overflow-hidden'
        >
          <div className='flex items-center gap-3 border-b border-[#1d3a2b] px-5 py-4 sm:px-6'>
            <span className='df-index'>01</span>
            <h2 className='text-sm font-bold tracking-wide text-[#ecf8ee]'>
              作战参数
            </h2>
          </div>

          <div className='space-y-5 p-5 sm:p-6'>
            <div className='grid gap-4 sm:grid-cols-2 lg:grid-cols-3'>
              {/* 地图 */}
              <label className='block'>
                <span className='df-label flex items-center gap-1.5'>
                  <Target className='h-3.5 w-3.5 text-[#7f9c8b]' />
                  地图
                </span>
                <div className='relative mt-1.5'>
                  <select
                    value={map}
                    onChange={event => handleMapChange(event.target.value)}
                    className='df-input df-select'
                  >
                    {MAP_CONFIGS.map(item => (
                      <option key={item.name} value={item.name}>
                        {item.name}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className='pointer-events-none absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[#7f9c8b]' />
                </div>
              </label>

              {/* 难度 */}
              <label className='block'>
                <span className='df-label flex items-center gap-1.5'>
                  <Crosshair className='h-3.5 w-3.5 text-[#7f9c8b]' />
                  行动难度
                </span>
                <div className='relative mt-1.5'>
                  <select
                    value={difficulty}
                    onChange={event => setDifficulty(event.target.value)}
                    className='df-input df-select'
                  >
                    {difficulties.map(item => (
                      <option key={item} value={item}>
                        {item}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className='pointer-events-none absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[#7f9c8b]' />
                </div>
              </label>

              {/* 预算 */}
              <div className='block sm:col-span-2 lg:col-span-1'>
                <label
                  htmlFor='budget-input'
                  className='df-label flex items-center gap-1.5'
                >
                  <span className='font-mono text-[11px] text-[#7f9c8b]'>
                    ₵
                  </span>
                  整套预算（万哈夫币）
                </label>
                <div className='relative mt-1.5'>
                  <input
                    id='budget-input'
                    type='number'
                    inputMode='decimal'
                    min='0.01'
                    step='0.01'
                    value={budgetRaw}
                    onChange={event => setBudgetRaw(event.target.value)}
                    onBlur={() => setBudgetTouched(true)}
                    aria-invalid={showBudgetError}
                    aria-describedby='budget-help'
                    className='df-input pr-24'
                    placeholder='例如 50'
                  />
                  <span className='pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-[11px] text-[#7f9c8b]'>
                    万哈夫币
                  </span>
                </div>
                <div className='mt-2 flex flex-wrap gap-1.5'>
                  {BUDGET_PRESETS.map(preset => (
                    <button
                      key={preset}
                      type='button'
                      onClick={() => {
                        setBudgetRaw(String(preset));
                        setBudgetTouched(true);
                      }}
                      className='df-chip'
                      data-active={budgetRaw === String(preset)}
                    >
                      {preset}万
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div id='budget-help' className='space-y-1.5'>
              <p className='text-[11px] leading-relaxed text-[#7f9c8b]'>
                预算覆盖
                <span className='text-[#b9d3c1]'>
                  枪械配件、装备、弹药与补给
                </span>
                ，按优先级配装。
                {budgetCap !== null
                  ? ` 当前难度参考上限 ${budgetCap} 万。`
                  : ''}
              </p>

              {showBudgetError ? (
                <p className='flex items-center gap-1.5 text-xs text-[#ff9a7a]'>
                  <AlertTriangle className='h-3.5 w-3.5' />
                  {budgetCheck.error}
                </p>
              ) : null}

              {overCap && budgetCap !== null ? (
                <p className='flex items-start gap-1.5 rounded-lg border border-[#6b5a2c] bg-[#2a220d]/60 px-3 py-2 text-[11px] leading-relaxed text-[#f5c45e]'>
                  <AlertTriangle className='mt-0.5 h-3.5 w-3.5 shrink-0' />
                  预算超过 {difficulty} 难度上限 {budgetCap} 万。仍按你填写的{' '}
                  {formatWan(budgetCheck.value ?? 0)}{' '}
                  万提交，超出部分会按上限封顶，原始预算不变。
                </p>
              ) : null}
            </div>

            {/* 更多选项 */}
            <div className='border-t border-[#1d3a2b] pt-4'>
              <button
                type='button'
                aria-expanded={advancedOpen}
                aria-controls='advanced-options'
                onClick={() => setAdvancedOpen(value => !value)}
                className='flex w-full items-center justify-between gap-3 text-left'
              >
                <span className='flex items-center gap-2 text-sm font-semibold text-[#cfe3d4]'>
                  <SlidersHorizontal className='h-4 w-4 text-[#8fae9a]' />
                  更多选项
                </span>
                <span className='flex items-center gap-2 font-mono text-[10px] tracking-wider text-[#6f8c7b]'>
                  特殊物品 · 破损防具
                  <ChevronDown
                    className={cn(
                      'h-4 w-4 transition-transform',
                      advancedOpen && 'rotate-180'
                    )}
                  />
                </span>
              </button>

              {advancedOpen ? (
                <div
                  id='advanced-options'
                  className='mt-3 grid gap-2.5 sm:grid-cols-2'
                >
                  <ToggleRow
                    checked={allowRare}
                    onChange={setAllowRare}
                    title='允许特殊物品'
                    description='允许六级头甲、AW、红色背包、金色及以上胸挂。'
                  />
                  <ToggleRow
                    checked={allowDamaged}
                    onChange={setAllowDamaged}
                    title='接受破损防具'
                    description='接受有价破损防具，便于在预算内保留更高防护等级。'
                  />
                </div>
              ) : null}
            </div>

            <div className='flex justify-end border-t border-[#1d3a2b] pt-5'>
              <button
                type='submit'
                disabled={running}
                className='df-btn-primary inline-flex h-12 shrink-0 items-center justify-center gap-2 rounded-xl px-6 text-sm font-black tracking-wide'
              >
                {running ? (
                  <Loader2 className='h-4 w-4 animate-spin' />
                ) : (
                  <Crosshair className='h-4 w-4' />
                )}
                {running ? '正在核价并生成配装…' : '一键生成配装'}
              </button>
            </div>
          </div>
        </form>

        {/* 结果区 */}
        <section
          ref={resultAnchorRef}
          className='mt-7 scroll-mt-4'
          aria-live='polite'
        >
          <SectionHeading
            index='02'
            title='作战结果'
            right={
              <span className='inline-flex items-center gap-1.5 font-mono text-[10px] tracking-wider text-[#8fae9a]'>
                <span
                  className={cn(
                    'h-1.5 w-1.5 rounded-full',
                    running
                      ? 'animate-pulse bg-[#c8f751]'
                      : error
                        ? 'bg-[#ff7a6b]'
                        : result
                          ? 'bg-[#c8f751]'
                          : 'bg-[#4f705d]'
                  )}
                />
                {statusLabel}
              </span>
            }
          />

          <div className='space-y-3'>
            {/* 执行中 */}
            {running && runningSnapshot ? (
              <div className='df-card relative overflow-hidden p-5 sm:p-6'>
                <div className='flex items-center gap-3.5'>
                  <span className='flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-[#c8f751]/40 bg-[#c8f751]/10'>
                    <Loader2 className='h-5 w-5 animate-spin text-[#c8f751]' />
                  </span>
                  <div className='min-w-0'>
                    <p className='text-base font-bold text-[#f1fbef]'>
                      正在核价 · 生成配装
                    </p>
                    <p className='mt-0.5 truncate text-xs text-[#8fae9a]'>
                      {runningSnapshot.map} · {runningSnapshot.difficulty} ·{' '}
                      {formatWan(runningSnapshot.budgetWan)} 万哈夫币
                    </p>
                  </div>
                </div>
                <p className='mt-3 text-xs leading-relaxed text-[#7f9c8b]'>
                  正在按预算计算配件、装备、弹药与补给，并生成完整图文报告。请稍候，完成后会自动展示。
                </p>
                <div className='mt-4 h-1 overflow-hidden rounded-full bg-[#12291d]'>
                  <div className='df-scanbar h-full w-1/3 rounded-full bg-[#c8f751]' />
                </div>
              </div>
            ) : null}

            {/* 错误 */}
            {error ? (
              <div role='alert' className='df-card border-[#6b3a2c] p-5 sm:p-6'>
                <div className='flex items-start gap-3'>
                  <AlertTriangle className='mt-0.5 h-5 w-5 shrink-0 text-[#ff9a7a]' />
                  <div className='min-w-0 flex-1'>
                    <p className='text-sm font-bold text-[#ffd0bf]'>
                      本次执行未完成
                    </p>
                    <p className='mt-1 text-sm leading-relaxed text-[#d9b3a5]'>
                      {error.message}
                    </p>
                    <p className='mt-1 font-mono text-[10px] tracking-wide text-[#a88478]'>
                      {error.snapshot.map} · {error.snapshot.difficulty} ·{' '}
                      {formatWan(error.snapshot.budgetWan)} 万哈夫币
                    </p>
                    {error.detail ? (
                      <div className='mt-3 rounded-lg border border-[#4a2a20] bg-[#210f0a]/60 px-3 py-2'>
                        <SafeMarkdown text={error.detail} className='text-xs' />
                      </div>
                    ) : null}
                    <button
                      type='button'
                      onClick={handleRetry}
                      disabled={running}
                      className='df-btn-ghost mt-3 inline-flex h-9 items-center gap-1.5 rounded-lg px-3 text-xs font-semibold'
                    >
                      <RotateCcw className='h-3.5 w-3.5' />
                      重试本次请求
                    </button>
                  </div>
                </div>
              </div>
            ) : null}

            {/* 成功结果（失败或重试中仍保留） */}
            {result ? (
              <article className='df-card overflow-hidden'>
                <div className='border-b border-[#1d3a2b] px-5 py-4 sm:px-6'>
                  <div className='flex flex-wrap items-start justify-between gap-3'>
                    <div className='min-w-0'>
                      <p className='font-mono text-[10px] tracking-[0.2em] text-[#8fae9a]'>
                        LOADOUT REPORT · READY
                      </p>
                      <h3 className='mt-1.5 text-lg font-black leading-snug text-[#f1fbef] sm:text-xl'>
                        {result.snapshot.map} · {result.snapshot.difficulty} ·{' '}
                        {formatWan(result.snapshot.budgetWan)} 万哈夫币
                      </h3>
                      <p className='mt-1 text-[11px] text-[#7f9c8b]'>
                        提交于 {formatTimestamp(result.snapshot.submittedAt)} ·{' '}
                        {result.source === 'history'
                          ? '本机历史记录'
                          : '实时结果'}
                      </p>
                    </div>
                    <span className='inline-flex items-center gap-1.5 rounded-full border border-[#3c6b4e] bg-[#0d2a1b] px-2.5 py-1 text-[10px] font-semibold tracking-wider text-[#c8f751]'>
                      <CheckCircle2 className='h-3 w-3' />
                      已生成
                    </span>
                  </div>

                  <div className='mt-3 flex flex-wrap gap-1.5 text-[10px] text-[#8fae9a]'>
                    <span className='rounded border border-[#1d3a2b] bg-[#06180f] px-2 py-0.5'>
                      特殊物品 {result.snapshot.allowRare ? '允许' : '关闭'}
                    </span>
                    <span className='rounded border border-[#1d3a2b] bg-[#06180f] px-2 py-0.5'>
                      破损防具{' '}
                      {result.snapshot.allowDamaged ? '接受' : '不接受'}
                    </span>
                    <span className='rounded border border-[#1d3a2b] bg-[#06180f] px-2 py-0.5 font-mono'>
                      {result.snapshot.map} / {result.snapshot.difficulty}
                    </span>
                  </div>
                </div>

                <div className='space-y-5 p-5 sm:p-6'>
                  {result.source === 'history' ? (
                    <p className='rounded-lg border border-[#1d3a2b] bg-[#0a2116] px-3 py-2 text-[11px] leading-relaxed text-[#8fae9a]'>
                      正在查看本机保存的摘要与完整报告；实时配装细节以报告内容为准。
                    </p>
                  ) : null}

                  {/* OUTPUT 摘要 */}
                  <div className='rounded-xl border border-[#1d3a2b] bg-[#03110b]/60 p-4 sm:p-5'>
                    <div className='mb-2 flex items-center gap-2 font-mono text-[10px] tracking-[0.18em] text-[#8fae9a]'>
                      <FileText className='h-3.5 w-3.5' />
                      配装摘要
                    </div>
                    {result.output ? (
                      <SafeMarkdown text={result.output} />
                    ) : (
                      <p className='text-sm text-[#8fae9a]'>
                        未返回文字摘要，请查看完整报告。
                      </p>
                    )}
                    <p className='mt-3 border-t border-[#143125] pt-2 text-[10px] leading-relaxed text-[#5f7a6a]'>
                      各风格预算与无方案理由以报告为准。
                    </p>
                  </div>

                  {/* 完整报告 */}
                  <div>
                    <div className='mb-2 flex items-center gap-2 font-mono text-[10px] tracking-[0.18em] text-[#8fae9a]'>
                      <FileText className='h-3.5 w-3.5' />
                      完整图文报告
                    </div>
                    {result.reportUrl ? (
                      <ReportViewer url={result.reportUrl} />
                    ) : (
                      <p className='rounded-xl border border-[#6b5a2c] bg-[#2a220d]/60 p-4 text-xs text-[#f5c45e]'>
                        本次未返回完整图文报告链接，可稍后重试。
                      </p>
                    )}
                  </div>
                </div>
              </article>
            ) : null}

            {/* 首次空状态 */}
            {!result && !running && !error ? (
              <div className='df-card flex flex-col items-center justify-center px-6 py-12 text-center'>
                <span className='flex h-14 w-14 items-center justify-center rounded-full border border-[#2a4436] bg-[#081c14]'>
                  <Target className='h-6 w-6 text-[#c8f751]' />
                </span>
                <p className='mt-4 text-base font-bold text-[#e6f2e9]'>
                  选好地图，出发前先算一笔
                </p>
                <p className='mt-1.5 max-w-md text-xs leading-relaxed text-[#7f9c8b]'>
                  填写上方作战参数后点击“一键生成配装”，按最新可用报价计算整套方案并生成图文报告。
                </p>
              </div>
            ) : null}
          </div>
        </section>

        {/* 历史 */}
        <section className='mt-7'>
          <SectionHeading
            index='03'
            title='最近战报'
            right={
              <span className='inline-flex items-center gap-1.5 font-mono text-[10px] tracking-wider text-[#6f8c7b]'>
                <History className='h-3 w-3' />
                仅本机保存 · 最多 5 份
              </span>
            }
          />
          <HistoryList
            entries={history}
            activeId={activeHistoryId}
            onSelect={handleSelectHistory}
          />
        </section>

        <footer className='mt-10 border-t border-[#1d3a2b]/80 pt-4 text-[10px] leading-relaxed text-[#4f705d]'>
          <p>价格以报告注明的报价时间为准，购买前请核价</p>
        </footer>
      </div>
    </div>
  );
}

export default Home;
