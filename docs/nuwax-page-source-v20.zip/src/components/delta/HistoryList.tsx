import { ChevronRight, History } from 'lucide-react';
import {
  formatTimestamp,
  formatWan,
  summarizeOutput,
  type HistoryEntry,
} from '@/lib/delta';
import { cn } from '@/lib/utils';

export interface HistoryListProps {
  entries: HistoryEntry[];
  activeId: string | null;
  onSelect: (entry: HistoryEntry) => void;
}

/** 最近 5 份成功报告，仅保存在本机。 */
export function HistoryList({ entries, activeId, onSelect }: HistoryListProps) {
  if (entries.length === 0) {
    return (
      <div className='df-card flex items-center gap-3 px-5 py-6 text-sm text-[#7f9c8b]'>
        <History className='h-4 w-4 shrink-0 text-[#4f705d]' />
        还没有历史战报。成功生成报告后，最近 5 份会保存在这台设备上。
      </div>
    );
  }

  return (
    <div className='grid gap-3 sm:grid-cols-2'>
      {entries.map(entry => {
        const active = entry.id === activeId;
        return (
          <button
            key={entry.id}
            type='button'
            onClick={() => onSelect(entry)}
            className={cn(
              'df-card group w-full p-4 text-left transition-colors',
              active
                ? 'border-[#c8f751]/60 bg-[#0d2a1b]'
                : 'hover:border-[#3c6b4e]'
            )}
          >
            <div className='flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1'>
              <div className='flex flex-wrap items-baseline gap-x-2 gap-y-1'>
                <span className='text-sm font-bold text-[#ecf8ee]'>
                  {entry.request.map} · {entry.request.difficulty}
                </span>
                <span className='text-xs font-semibold text-[#c8f751]'>
                  {formatWan(entry.request.budgetWan)} 万
                </span>
              </div>
              <span className='font-mono text-[10px] tracking-wider text-[#6f8c7b]'>
                {formatTimestamp(entry.savedAt)}
              </span>
            </div>

            <p className='mt-2 line-clamp-2 text-xs leading-relaxed text-[#8fae9a]'>
              {summarizeOutput(entry.summary)}
            </p>

            <span className='mt-3 inline-flex items-center gap-1 text-[11px] font-semibold text-[#9fd62e] group-hover:text-[#c8f751]'>
              重新查看
              <ChevronRight className='h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5' />
            </span>
          </button>
        );
      })}
    </div>
  );
}
