import { Fragment, type ElementType, type ReactNode } from 'react';
import { cn } from '@/lib/utils';

/**
 * 轻量、安全的 Markdown 渲染：只生成 React 节点，不使用
 * dangerouslySetInnerHTML。
 *
 * 链接规则：
 * - 仅保留 http/https 链接，统一以可点击形式展示；
 * - 链接文字如果是裸 URL、超长串或 base64，则替换为友好文案，
 *   不在页面上暴露链接原文。
 */

const INLINE_PATTERN =
  /(!?\[[^\]]*\]\(https?:\/\/[^\s)]+\)|\*\*[^*]+\*\*|`[^`]+`|\*[^*]+\*|https?:\/\/[^\s<>"'()[\]{}，。；、！？]+)/g;

const LONG_TOKEN_PATTERN = /[A-Za-z0-9+/=_-]{80,}/g;

function maskLongTokens(text: string): string {
  return text
    .replace(/#r=[A-Za-z0-9+/=%._-]{20,}/g, '［报告参数已省略］')
    .replace(LONG_TOKEN_PATTERN, '［长内容已省略］');
}

function isRedactedLabel(label: string): boolean {
  const clean = label.replace(/[*_`~]/g, '').trim();
  if (!clean) return true;
  if (/^(https?:\/\/|data:|#r=)/i.test(clean)) return true;
  if (clean.length > 60 && !/\s/.test(clean)) return true;
  return /[A-Za-z0-9+/=_-]{80,}/.test(clean);
}

function linkLabel(label: string, fallback: string): string {
  const clean = label.replace(/[*_`~]/g, '').trim();
  return isRedactedLabel(clean) ? fallback : clean;
}

function splitTrailingPunctuation(value: string): {
  url: string;
  trailing: string;
} {
  const match = value.match(/^(.*?)([.,;:!?]+)$/);
  if (!match) return { url: value, trailing: '' };
  return { url: match[1], trailing: match[2] };
}

function renderLink(href: string, label: string, key: string): ReactNode {
  return (
    <a
      key={key}
      href={href}
      target='_blank'
      rel='noopener noreferrer'
      className='break-words font-medium text-[#c8f751] underline decoration-[#c8f751]/40 underline-offset-2 transition-colors hover:text-[#dcff82]'
    >
      {label}
    </a>
  );
}

function renderInline(text: string, keyPrefix: string): ReactNode[] {
  const parts = text.split(INLINE_PATTERN);

  return parts.map((part, index) => {
    const key = `${keyPrefix}-${index}`;
    if (!part) return null;

    const image = part.match(/^!\[([^\]]*)\]\((https?:\/\/[^\s)]+)\)$/);
    if (image) {
      return renderLink(image[2], linkLabel(image[1], '查看图片'), key);
    }

    const link = part.match(/^\[([^\]]*)\]\((https?:\/\/[^\s)]+)\)$/);
    if (link) {
      return renderLink(link[2], linkLabel(link[1], '查看完整图文报告'), key);
    }

    if (/^https?:\/\//i.test(part)) {
      const { url, trailing } = splitTrailingPunctuation(part);
      return (
        <Fragment key={key}>
          {renderLink(url, '查看完整图文报告', `${key}-link`)}
          {trailing}
        </Fragment>
      );
    }

    if (part.startsWith('**') && part.endsWith('**') && part.length > 4) {
      return (
        <strong key={key} className='font-semibold text-[#f1fbef]'>
          {part.slice(2, -2)}
        </strong>
      );
    }
    if (part.startsWith('`') && part.endsWith('`') && part.length > 2) {
      return (
        <code
          key={key}
          className='rounded bg-[#12301f] px-1.5 py-0.5 font-mono text-[0.85em] text-[#c8f751]'
        >
          {part.slice(1, -1)}
        </code>
      );
    }
    if (part.startsWith('*') && part.endsWith('*') && part.length > 2) {
      return (
        <em key={key} className='italic text-[#dbeadf]'>
          {part.slice(1, -1)}
        </em>
      );
    }
    return <Fragment key={key}>{maskLongTokens(part)}</Fragment>;
  });
}

export interface SafeMarkdownProps {
  text: string;
  className?: string;
}

export function SafeMarkdown({ text, className }: SafeMarkdownProps) {
  const safeText = text
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/?[a-zA-Z][^>]*>/g, '')
    .replace(/!\[[^\]]*\]\(data:[^)]*\)/gi, '［图片已省略］')
    .replace(/\[([^\]]*)\]\(data:[^)]*\)/gi, '$1')
    .replace(/\bdata:[^\s<>"')]+/gi, '［内容已省略］');

  const lines = safeText.replace(/\r\n/g, '\n').split('\n');
  const blocks: ReactNode[] = [];
  let list: { type: 'ul' | 'ol'; items: string[] } | null = null;

  const flushList = (key: string) => {
    if (!list) return;
    const current = list;
    list = null;
    const Tag: ElementType = current.type;
    blocks.push(
      <Tag
        key={key}
        className={cn(
          'my-2 space-y-1.5 pl-5 text-[#c9dccd]',
          current.type === 'ul' ? 'list-disc' : 'list-decimal'
        )}
      >
        {current.items.map((item, index) => (
          <li key={`${key}-${index}`} className='leading-relaxed'>
            {renderInline(item, `${key}-${index}`)}
          </li>
        ))}
      </Tag>
    );
  };

  lines.forEach((line, index) => {
    const trimmed = line.trim();
    const key = `block-${index}`;

    if (!trimmed) {
      flushList(`list-${index}`);
      return;
    }

    if (/^([-*_]){3,}$/.test(trimmed)) {
      flushList(`list-${index}`);
      blocks.push(<hr key={key} className='my-4 border-[#1d3a2b]' />);
      return;
    }

    const heading = trimmed.match(/^(#{1,6})\s+(.*)$/);
    if (heading) {
      flushList(`list-${index}`);
      const level = heading[1].length;
      const HeadingTag: ElementType = level <= 2 ? 'h3' : 'h4';
      blocks.push(
        <HeadingTag
          key={key}
          className={cn(
            'mt-4 mb-2 font-bold text-[#f1fbef] first:mt-0',
            level <= 2 ? 'text-base' : 'text-sm'
          )}
        >
          {renderInline(heading[2], key)}
        </HeadingTag>
      );
      return;
    }

    const unordered = trimmed.match(/^[-*•]\s+(.*)$/);
    if (unordered) {
      if (!list || list.type !== 'ul') {
        flushList(`list-${index}`);
        list = { type: 'ul', items: [] };
      }
      list.items.push(unordered[1]);
      return;
    }

    const ordered = trimmed.match(/^\d+[.)、]\s+(.*)$/);
    if (ordered) {
      if (!list || list.type !== 'ol') {
        flushList(`list-${index}`);
        list = { type: 'ol', items: [] };
      }
      list.items.push(ordered[1]);
      return;
    }

    const quote = trimmed.match(/^>\s?(.*)$/);
    if (quote) {
      flushList(`list-${index}`);
      blocks.push(
        <blockquote
          key={key}
          className='my-2 border-l-2 border-[#3c6b4e] pl-3 text-[#a9c2b1]'
        >
          {renderInline(quote[1], key)}
        </blockquote>
      );
      return;
    }

    flushList(`list-${index}`);
    blocks.push(
      <p key={key} className='my-1.5 leading-relaxed text-[#c9dccd]'>
        {renderInline(trimmed, key)}
      </p>
    );
  });

  flushList('list-final');

  if (blocks.length === 0) {
    return (
      <p className={cn('text-sm text-[#8ba797]', className)}>
        未返回文字摘要。
      </p>
    );
  }

  return (
    <div className={cn('text-sm sm:text-[15px]', className)}>{blocks}</div>
  );
}
