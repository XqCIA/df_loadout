import { useEffect, useRef, useState } from 'react';
import {
  AlertTriangle,
  Check,
  Copy,
  ExternalLink,
  FileWarning,
} from 'lucide-react';
import { isAllowedReportUrl } from '@/lib/delta';

type CopyState = 'idle' | 'copied' | 'failed';

function fallbackCopy(text: string) {
  const textarea = document.createElement('textarea');
  textarea.value = text;
  textarea.setAttribute('readonly', '');
  textarea.style.position = 'fixed';
  textarea.style.top = '-1000px';
  textarea.style.opacity = '0';
  document.body.appendChild(textarea);
  textarea.select();
  const ok = document.execCommand('copy');
  document.body.removeChild(textarea);
  if (!ok) throw new Error('copy failed');
}

export interface ReportViewerProps {
  url: string;
}

/**
 * 报告展示：iframe 直接使用工作流返回的完整 URL（不重编码、不截断），
 * 同时常驻“新窗口查看 / 复制链接”操作，iframe 失败也不影响链接可用。
 */
export function ReportViewer({ url }: ReportViewerProps) {
  const allowed = isAllowedReportUrl(url);
  const [copied, setCopied] = useState<CopyState>('idle');
  const [loaded, setLoaded] = useState(false);
  const [slow, setSlow] = useState(false);
  const copyTimer = useRef<number | null>(null);

  useEffect(() => {
    setLoaded(false);
    setSlow(false);
    const timer = window.setTimeout(() => setSlow(true), 12_000);
    return () => window.clearTimeout(timer);
  }, [url]);

  useEffect(
    () => () => {
      if (copyTimer.current) window.clearTimeout(copyTimer.current);
    },
    []
  );

  const handleCopy = async () => {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(url);
      } else {
        fallbackCopy(url);
      }
      setCopied('copied');
    } catch {
      try {
        fallbackCopy(url);
        setCopied('copied');
      } catch {
        setCopied('failed');
      }
    }

    if (copyTimer.current) window.clearTimeout(copyTimer.current);
    copyTimer.current = window.setTimeout(() => setCopied('idle'), 2200);
  };

  if (!allowed) {
    return (
      <div className='rounded-xl border border-[#6b3a2c] bg-[#2a130d]/70 p-4'>
        <div className='flex items-start gap-2.5'>
          <FileWarning className='mt-0.5 h-4 w-4 shrink-0 text-[#ff9a7a]' />
          <div>
            <p className='text-sm font-medium text-[#ffd0bf]'>
              报告链接无法安全展示
            </p>
            <p className='mt-1 text-xs leading-relaxed text-[#c99a8a]'>
              本次报告链接未展示，请稍后重试。
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className='space-y-3'>
      <div className='flex flex-wrap items-center gap-2.5'>
        <a
          href={url}
          target='_blank'
          rel='noopener noreferrer'
          className='df-btn-primary inline-flex h-10 items-center gap-2 rounded-xl px-4 text-sm font-bold'
        >
          <ExternalLink className='h-4 w-4' />
          新窗口查看完整报告
        </a>
        <button
          type='button'
          onClick={() => void handleCopy()}
          className='df-btn-ghost inline-flex h-10 items-center gap-2 rounded-xl px-4 text-sm font-semibold'
        >
          {copied === 'copied' ? (
            <Check className='h-4 w-4 text-[#c8f751]' />
          ) : (
            <Copy className='h-4 w-4' />
          )}
          {copied === 'copied' ? '已复制' : '复制报告链接'}
        </button>
      </div>

      {copied === 'failed' ? (
        <p className='text-xs text-[#ff9a7a]'>
          复制失败，请点击“新窗口查看完整报告”后手动复制地址。
        </p>
      ) : null}

      <div className='overflow-hidden rounded-xl border border-[#1d3a2b] bg-[#03100a]'>
        <iframe
          key={url}
          src={url}
          title='三角洲配装完整报告'
          loading='eager'
          referrerPolicy='no-referrer-when-downgrade'
          onLoad={() => setLoaded(true)}
          className='block h-[560px] w-full border-0 sm:h-[720px] lg:h-[900px]'
        />
      </div>

      <div className='text-[11px] text-[#6f8c7b]'>
        {slow && !loaded
          ? '报告加载较慢或无法在页面内显示，请点击上方按钮在新窗口查看。'
          : '报告为实时生成，完整图文以报告内容为准。'}
      </div>

      {slow && !loaded ? (
        <p className='flex items-center gap-1.5 text-xs text-[#f5c45e]'>
          <AlertTriangle className='h-3.5 w-3.5' />
          报告暂时未完成加载，链接按钮仍然可用。
        </p>
      ) : null}
    </div>
  );
}
